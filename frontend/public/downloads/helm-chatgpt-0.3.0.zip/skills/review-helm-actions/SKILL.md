---
name: review-helm-actions
description: Use when a Helm action needs review, returns APPROVAL_PENDING or a jobId, or the user asks whether a queued memory, email, file, or calendar action completed.
---

# Review Helm actions

First apply the bundled `start-helm-session` skill to establish or reuse this chat's verified context. If it is unavailable, report the incomplete plugin rather than guess a connection. For an existing job, select its originating agent; if unknown, ask before polling. A job outside this chat's active context requires the session skill's context-change procedure. Existing jobs retain their origin even after a switch: never send an old job ID to the newly selected agent. Use the originating child's actual host-exposed tools, matched by canonical name; the master directory cannot inspect or approve jobs.

For a new consequential action, show its concrete effects before invoking the existing review workflow: affected memory and scope, exact email recipients/subject/body/attachments, or calendar dates/timezone/attendees and notifications. Use a server-provided preview when available. Respect authorization already given for that exact action; Helm's required confirmation still applies. Never invent a review tool or fabricate an approval field.

## Approval jobs

When a tool returns `APPROVAL_PENDING` and a `jobId`, call `get_result` with that ID on the same connection. Helm delivers its confirmation through the configured channel; polling cannot approve the action. Do not resend the original mutation to check status.

Poll at the server's suggested interval, or 3–5 seconds if unspecified, for up to 12 polls in this turn. Then report it as pending with its ID; it may be checked later. Silence, elapsed time, or a disconnected chat is not approval.

| Status | Response |
| --- | --- |
| `pending` | Continue bounded polling; no success claim |
| `completed` | Inspect the nested `result`, including `isError`, error/status fields, and returned content. Report success only when execution succeeded |
| `rejected` or `expired` | Stop this operation and report that outcome; do not automatically resubmit |
| `changes_requested` | Read `feedback` and revise only the requested action within the user's scope. Submit the corrected call through Helm's review process; an identical retry is not a correction |
| Execution error or unknown outcome | Report the error and uncertainty; inspect read-only status where available before any retry |

Do not retry an email send or other external mutation after a timeout merely because the job completed or approval was granted. The effect may already have happened. For email, use Helm's supported draft-then-send flow (`gmail_create_draft`, then `gmail_send_draft` with the returned draft ID); a job ID is not a draft ID. Use these tools only if present and when the user requested the action.

If the user asks to list pending actions, use an advertised listing tool when available. `get_result` alone can inspect only a known job, so do not fabricate a queue listing. Reconnection is specific to the selected endpoint; do not change accounts to bypass a failed approval.

Return the actual outcome, affected item, originating connection and ID, and any unresolved decision. Distinguish approval received, execution succeeded, execution failed, and delivery unconfirmed.
