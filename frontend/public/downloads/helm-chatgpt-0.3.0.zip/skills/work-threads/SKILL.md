---
name: work-threads
description: Use when the user asks about Helm threads, asks what is active or due, wants to pick up, update, release or close a thread, or when a topic with a goal and a deadline that will take attention over days or weeks deserves a thread to be suggested.
---

# Work with Helm threads

A thread is a first-class Helm object the user creates for something that needs their attention: a goal, a Past / Now / Next narrative, todos, deadlines, reminders, an event timeline, sources and watchers. It lives in one memory scope and is backed by memory, but it is not a memory entry. See [the Helm model](../start-helm-session/references/helm-model.md).

First apply the bundled `start-helm-session` skill to establish or reuse this chat's verified agent and memory scope. Use only that child's `thread_*` tools. If it has none, say the Threads service is not enabled on the agent and stop.

Call `skills_get` with slug `threads` once per chat. If the agent returns it, follow it; it takes precedence over the rules below. If it is unknown or unassigned, use these rules.

## Approvals

`thread_propose`, `thread_close` and `thread_add_watcher` require the user's approval on their phone and return `APPROVAL_PENDING` with a `jobId`. Follow the bundled `review-helm-actions` workflow. Never call the same tool again while it is pending, and never report a proposal as a created thread.

## Suggest a thread

Suggest a thread only for a topic with a goal or deadline that will take attention over days or weeks. A one-off question is not a thread, and something without an end is a project in memory.

1. Call `thread_list` in the selected scope so you do not duplicate one.
2. Draft `title`, `goal`, `target_date`, `past`, `now`, `next` and `scope`. Add a watcher only if the user wants one, choosing the narrowest source they can already read: one Gmail thread, then a sender, then a tight query; a Hermeneutix meeting before a whole project.
3. Show the draft. Call `thread_propose` only after the user agrees.

## Work a thread

1. Find it with `thread_list`, then read `thread_get_brief`. Summarise Past, Now and Next in at most five lines, and surface anything due or new candidates first.
2. Log what happened with `thread_log_event`. Add todos, deadlines (`due_at`), reminders (`remind_at`) and milestones with `thread_add_item`; change them with `thread_update_item`.
3. Keep the narrative current with `thread_update_now` (`now`, `next` replace; `past_append` adds).
4. Show watcher candidates and accept or dismiss each only with the user's agreement.
5. Durable detail goes into memory in the thread's scope through the bundled `maintain-memory` workflow, then is linked with `thread_attach_source` (`source_type: "memory"`, `memory_entry_id`). Never change a thread with memory tools.
6. Pause, resume or close only when the user asks. To close, read the brief, draft a retrospective, propose `cancel` or `carry` for every open item, and call `thread_close` after the user agrees.

Return what changed on the thread, and any pending approval with its job ID.
