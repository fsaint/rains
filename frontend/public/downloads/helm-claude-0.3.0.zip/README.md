# Helm plugin for Claude Code and Cowork (v0.3.0)

Use Helm (https://app.helm.mom) from Claude with **one Helm scope per
project**. Each scope (Helm calls it an agent: Anchorsite, LVA, Seer,
Unholster, …) is a role identity defined by its MCP URL, with its own tools,
memory, skills, threads, mail and Drive, so projects stay focused and nothing
leaks across them. The full model is in
[`skills/helm-session/references/helm-model.md`](skills/helm-session/references/helm-model.md).

## Components

| Component | Purpose |
|---|---|
| `helm-root` MCP (`https://app.helm.mom/mcp`) | Discovery only: `helm_list_agents` returns each agent with its `mcp_url`. It cannot act on any agent. |
| `helm-lock` skill | Locks the project to one scope. Claude Code: a `helm` server in the project's `.mcp.json` at the scope's URL, deny rules for the other Helm connectors in `.claude/settings.local.json`, and the lock `.claude/helm-scope.json`. Cowork: the lock file only. claude.ai Projects: a `Helm scope:` instruction line. |
| `helm-session` skill | Binds the session: from the lock when there is one (verified by `whoami` agent id, no switching), otherwise by choosing an agent. Then boots the scope: tool inventory, live `skills_list`, memory scope, active threads, memory search for the request's context. |
| `helm-threads` skill | Suggests, picks up, updates and closes threads, linking their detail to memory. Uses the scope's live `threads` skill, or a bundled fallback. |
| Live skill stubs | Each carries the Helm skill's trigger description and fetches the live instructions from the **bound** agent with `skills_get`. |
| `helm-sync` skill | Rebuilds the stubs from all connected agents' rosters when skills are added, removed or renamed, then packages a new plugin version. |
| `helm-skill-authoring` skill | Creates, uploads, edits and assigns skills through the bound scope's `skill_authoring_*` tools, for that scope only, or in the helm-skills repo. Never round-trips rendered `skills_get` output. |
| SessionStart hook | Names the project's locked scope (or asks Claude to bind one) and lists the installed skill stubs so drift from the live roster shows. |
| PreToolUse scope guard | Locked: allows only the lock's server, after its `whoami` returned the locked agent id; refuses blocked servers and any other proven Helm agent; ignores bind/unbind lines. Unlocked: blocks calls to any agent other than the bound one. Non-Helm tools pass. |
| UserPromptSubmit hook (memory checkpoint) | After enough new conversation with no write to the bound agent's memory, adds a short checkpoint note to Claude's context with your next message (no "Stop hook error" banner). Claude runs `helm-memory-update` against the bound agent only. Unbound sessions never write memory. |
| `helm-memory-update` skill | Uses the bound agent's live skill when assigned, otherwise a bundled fallback. Helm-sync leaves it alone. |

## Setup

1. Install the plugin and sign in to `helm-root` when prompted. If you
   already added the root as a separate connector, you can remove that one.
2. Each agent you want to work in needs its own connector, because Helm
   authorizes per agent. Add its `mcp_url` (ask Claude "list my Helm agents")
   as a custom connector in Claude.
3. Lock each project to its scope: in the project, ask Claude to "lock this
   project to <agent>" (`helm-lock`).
   - **Claude Code:** restart in the folder, approve the `helm` server and
     sign in with `/mcp`. Enforcement: the project's own MCP server, native
     permission deny rules, and the scope guard.
   - **Cowork:** uses the scope's connector; enforcement is the scope guard.
   - **claude.ai Projects:** paste the `Helm scope:` line into the Project
     instructions. No hooks run there, so this relies on Claude following
     `helm-session`.
   A legacy `.helm-scope` file (agent name only) is still read as a hint.
4. Remove account-level copies of the Helm skills, so the live stubs don't
   compete with them for triggers.

## Environment variables

| Variable | Effect |
|---|---|
| `HELM_GUARD=off` | Disables the scope guard. |
| `HELM_GUARD_WAIT` (default 1.5) | Seconds the guard re-reads the transcript for a same-turn bind announcement before refusing a call. |
| `HELM_MEMORY_AUTO=off` | Disables memory checkpoints. |
| `HELM_MEMORY_MIN_CHARS` (default 300), `HELM_MEMORY_MIN_TURNS` (default 4) | How much new conversation triggers a checkpoint. |

The hooks need `python3`. Without it, they do nothing.

## Suggested server-side changes (Helm)

- Fill in each agent's `description` in `helm_list_agents` (most are null).
  Claude matches topics to agents with it.
- Add memory scopes and the Hermeneutix project to each `helm_list_agents`
  entry, so Claude can choose a scope without connecting to the agent first.
- Skill authoring per scope, limited to the scope's own skills, so a locked
  project can create and assign skills without Architect.
- Extend the root's standing instructions, which Claude receives
  automatically on connect, with the scoping rule: "One agent per session.
  Bind before acting, announce the binding, never read from, write to or copy
  between other agents, and switch only on the user's explicit request."
