---
name: helm-threads
description: "Use when the user asks to pick up, continue, work on, update, release or close a Helm thread, asks what threads are active or what is due, or when a topic with a goal and a deadline that will take attention over days or weeks deserves a thread (suggest one). Also use to log events, todos, deadlines and Now/Next on a held thread. (Prefers the live Helm `threads` skill; falls back to the copy bundled with the plugin.)"
metadata:
  helm-slug: threads
  version: "0.3.0"
---

# Helm threads

A thread is a first-class Helm object: something the user decided needs their
attention, with a goal, a Past / Now / Next narrative, todos and deadlines,
reminders, an event timeline, sources and watchers. It lives in one memory
scope and is backed by memory, but it is not a memory entry. See
[the Helm model](../helm-session/references/helm-model.md).

## 1. Pick the instructions (once per session)

1. Use the Helm scope bound to this session (see `helm-session`). If none is
   bound, bind one first. Never touch another scope's threads.
2. Call `skills_get` with slug `threads` on the bound connection, **once per
   session**.
   - If it returns the skill, follow it. It takes precedence over this file.
   - If it is unknown or not assigned, use the bundled instructions below and
     mention once that the `threads` skill can be assigned to this scope in
     the dashboard (Agents → the agent → Skills).
3. If the scope has no `thread_*` tools, say the Threads service is not
   enabled on it and stop.

## 2. Bundled instructions (fallback)

### Approval-locked tools

`thread_propose`, `thread_close` and `thread_add_watcher` go to the user's
phone. They return `APPROVAL_PENDING` with a `jobId`: nothing has happened
yet. Call `get_result` with the `jobId`, poll every 3–5 seconds until
`completed`, `rejected` or `changes_requested`, and tell the user it awaits
their approval. Never call the tool again while it is pending.

### Suggest a thread

Suggest one only for a topic with a goal or deadline that will take real
attention over days or weeks: not a one-off question, not something without
an end (that is a project in memory).

1. `thread_list` (in the bound memory scope) to make sure it doesn't exist.
2. Draft `title`, `goal` (what done looks like), `target_date`, `past`, `now`,
   `next`, and the `scope`. Add a watcher only if the user wants one, and
   only the narrowest that fits: one Gmail thread, then one sender, then a
   tight query; a Hermeneutix meeting before a whole project. Only watch a
   source you can already read.
3. Show the draft to the user. On a yes, call `thread_propose` and follow the
   approval steps.

When you notice such a topic during other work, offer the thread in one line;
don't propose without the user's yes.

### Pick up a thread

1. Find it with `thread_list` if you have no id.
2. `thread_get_brief`. Summarise Past, Now and Next in at most five lines.
3. Print once, on its own line: `Helm thread held: <title>`

### While a thread is held

- At the start of each working turn, `thread_get_brief` again. Surface what
  is due or has fired first.
- Candidates from watchers: show them and ask. `thread_accept_candidate` for
  ones that belong, `thread_dismiss_candidate` for ones that don't.
- Something happened (a call, a decision, a delivery): `thread_log_event`.
- Something to do: `thread_add_item` (`todo`, `deadline` with `due_at`,
  `reminder` with `remind_at`, `milestone`); change or finish it with
  `thread_update_item`.
- Keep the narrative current with `thread_update_now`: `now` and `next`
  replace, `past_append` adds.
- **Backed by memory.** Durable detail (people, decisions, documents) goes into
  memory in the thread's scope, through `helm-memory-update`. Then link it:
  `thread_attach_source` with `source_type: "memory"` and `memory_entry_id`.
  Attach the emails and meetings that matter the same way. Never change a
  thread with `memory_update`.
- Stay on the thread. If the user turns to something unrelated, say the
  thread is held and ask whether to release it.
- `thread_pause` / `thread_resume` only when the user asks.

### Release and close

- Release only when the user asks: print `Helm thread released`. The thread
  stays active.
- Close when the goal is met or the user ends it: `thread_get_brief`, draft a
  retrospective, propose `cancel` or `carry` (with `successor_thread_id`) for
  every open item, and on the user's yes call `thread_close` with
  `thread_id`, `retrospective` and `decisions`. Record the outcome on the
  parent project in memory in one or two lines.
