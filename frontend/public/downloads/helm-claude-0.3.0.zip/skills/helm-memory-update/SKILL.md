---
name: helm-memory-update
description: "Use at checkpoints during a conversation and again at its end, or when asked to remember, log, or capture what was just discussed — extracts the people, companies, projects, and facts the conversation established, matches them against what is already stored, and updates or creates entries accordingly. (Prefers the live Helm skill; falls back to the copy bundled with the plugin.)"
metadata:
  helm-slug: helm-memory-update
  version: "0.2.4"
---

# Helm Memory Update

This skill prefers the live Helm version and falls back to the bundled one
below. Helm-sync never regenerates this file.

## 1. Pick the instructions (once per session)

1. Use the Helm agent bound to this session (see `helm-session`). If none is
   bound, stop: unscoped sessions never write memory.
2. Call `skills_get` with slug `helm-memory-update` on the bound agent's
   connection, **once per session**.
   - If it returns the skill, follow those instructions. They take
     precedence over this file.
   - If it says the skill is unknown, or "exists but is not assigned to you",
     use the bundled instructions below. Do not call `skills_get` again for it
     this session. Do not borrow the skill from another agent. Mention once,
     briefly, that the skill can be assigned to this agent in the Helm
     dashboard (Agents → the agent → Skills).

## 2. Bundled instructions (fallback)

Write only through the bound agent's connection and only to its memory scopes
(from `whoami` limits). If it has several scopes, pick by topic or ask.

**What to file.** Only durable facts this conversation actually established:
people, companies, projects, decisions, commitments, preferences, dates. Skip
speculation, small talk and anything already stored. Never store credentials,
tokens, API keys, agent ids or MCP URLs.

**Find before you write.**
1. `memory_search` for each entity. Avoid duplicates; update an existing
   entry instead of creating a new one.
2. Fetch the match by **id** with `memory_get` (not by title), and note its
   `version`.

**Update, don't resend.**
- Use `memory_update` with `section` or `append`, and always pass
  `if_version` with the version you just read.
- Never resend a whole body with `content`. A full resend can silently drop
  sections. Use `content` only for a brand-new entry you just created.
- `section` with `mode: "append"` adds text at the **end** of that section.
  To put a new entry at the **top** of a section (for example the newest
  item in a `Status` section), read the section, then use `section` with
  `mode: "replace"` and the whole new section body, new item first.
- On `VERSION_CONFLICT`, re-read the entry by id and re-apply your change.
  Don't fall back to `content`.

**Create and link.**
- New entity: `memory_create` with the right type (person, company,
  project, note) in the right scope, with a short factual body.
- Relationships: `memory_relate` (person works at company, project belongs
  to company).
- When you add significant new entries, add one line to the scope's index
  with `append` or `section`, never a full resend.

**Report.** One short line naming what you filed. If nothing qualified, say
nothing (during an automatic checkpoint) or "No Helm memory update." (when
asked directly).
