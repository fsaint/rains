---
name: helm-sync
description: "This skill should be used when the user says \"sync Helm skills\", \"refresh my Helm skills\", \"update the Helm plugin\", \"I added a skill in Helm\", or \"why doesn't Claude see my new Helm skill\", or when a live Helm skill stub reports that a slug is unknown or unassigned. It rebuilds the plugin's local skill stubs from Helm's live roster and packages a new plugin version to install.\n"
metadata:
  version: "0.1.0"
---

# Sync Helm skills into the plugin

The plugin holds one small **stub** per Helm skill. A stub carries the skill's
real trigger description, so Claude knows when to use it, and its body only
says to fetch the live instructions with `skills_get`. Because the body is
always fetched live, edits to a skill's text never need a sync. A sync is
needed only when a skill is **added, removed, renamed, or its description
changes**.

A sync is not needed to *use* a new skill: the `helm-session` boot reads the
bound scope's `skills_list`, and any listed skill can be run with
`skills_get` right away. Stubs only give Claude the skill's trigger
description in every session, so it is picked up without being asked.

## Steps

1. **Collect the roster.** In a project locked to a scope (see `helm-lock`),
   only that scope's `skills_list` counts: other scopes are blocked there, so
   report drift for the locked scope and say a full sync must run from an
   unlocked session. Otherwise, call `helm_list_agents` on the root to see every
   agent. For each agent that is connected here (its `whoami` matches), call
   `skills_list` with `include_unavailable: true`. These are discovery calls,
   so they are allowed whatever agent the session is bound to. Merge by slug,
   and set `"server"` to the agent name or names that have the skill. List
   any agents that aren't connected, so the user knows the roster may be
   incomplete. If two agents
   have the same slug with different descriptions, keep the higher version.
   Write the merged list as JSON to a scratch file. Do not call `skills_get`
   here; the bodies are not needed.

2. **Get a working copy of the plugin.** Copy the installed plugin directory to
   scratch space. To find it, start from `${CLAUDE_PLUGIN_ROOT}`; failing that,
   run
   `find mnt/.local-plugins mnt/.plugins ~/.claude/plugins -type d -name "helm*" 2>/dev/null`
   and pick the directory whose `.claude-plugin/plugin.json` has `"name": "helm"`.
   Never edit the installed copy in place.

3. **Dry run.**
   `python3 <copy>/skills/helm-sync/scripts/generate_stubs.py <roster.json> <copy> --dry-run`
   If `added`, `updated` and `removed` are all empty, report "already in sync",
   mention any `version_bumps_only` (informational only; they're already live),
   and stop.

4. **Show the diff to the user.** Show which skills are added, which are
   removed and which descriptions changed, in plain language, and get a yes.

5. **Apply.** Run the script without `--dry-run`. Bump the patch version in
   `<copy>/.claude-plugin/plugin.json`.

6. **Package and deliver.**
   `cd <copy> && zip -r /tmp/helm.plugin . -x "*.DS_Store"`
   Send it with `SendUserFile`, captioned with the change summary. The user
   installs it from the preview card, which replaces the old version.

## Rules

- The script only creates, rewrites or deletes stub directories, which it
  identifies by a marker in their frontmatter. It never touches the core
  skills (`helm-session`, `helm-sync`, `helm-skill-authoring`, `helm-lock`) or
  the hybrid ones (`helm-memory-update`, and `helm-threads`, which covers the
  `threads` slug). A remote slug that collides with a core name becomes
  `remote-<slug>`.
- Never write a skill's body from `skills_get` into the plugin. `skills_get`
  serves skills with `{{skill:}}` tokens already rendered, so the copy goes
  stale and drifts from source.
- If the user also has account-level copies of the same Helm skills (for
  example under `anthropic-skills:`), point out the duplicates, which compete
  for the same triggers, and suggest removing them in favor of the live stubs.
