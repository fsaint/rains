#!/usr/bin/env python3
"""Regenerate Helm skill stubs inside this plugin.

Usage:
    python3 generate_stubs.py <roster.json> <plugin_root> [--dry-run]

<roster.json> is either the raw skills_list response ({"skills": [...]}) or a
plain list of skill objects. Each object needs slug and description; name,
version, requires and server (the connector it came from) are optional.

Only directories whose SKILL.md frontmatter carries `helm-stub: "true"` are
ever created, rewritten or removed. Core and hybrid plugin skills are never touched.
"""
import json
import re
import shutil
import sys
from datetime import date
from pathlib import Path

CORE = {"helm-sync", "helm-session", "helm-skill-authoring", "helm-lock"}
# Plugin skills that already fetch a live Helm skill and carry a bundled
# fallback, keyed by the Helm slug they cover. No stub is generated for them.
HYBRID = {"helm-memory-update": "helm-memory-update", "threads": "helm-threads"}
SLUG_RE = re.compile(r"^[a-z0-9][a-z0-9-]{0,62}[a-z0-9]$")

TEMPLATE = """---
name: {dir_name}
description: {description}
metadata:
  helm-stub: "true"
  helm-slug: {slug}
  helm-version: {version}
  helm-requires: {requires}
  synced: {synced}
---

# {title} (live Helm skill)

This is a pointer, not the skill. The real instructions live on Helm and can
change at any time.

1. Use the Helm agent bound to this session (see `helm-session`). If none is
   bound yet, bind one first. Never reach into another agent to run this.
2. Call `skills_get` with slug `{slug}` on the bound agent's connection. Read
   the whole body. If the bound agent doesn't have this skill, say so and
   name the agents that do{server_hint}. Don't switch agents unless the user
   says to.
3. Follow those instructions exactly. They take precedence over this stub and
   over anything remembered from an earlier session. Never answer from a cached
   copy.
4. If the response lists `unavailable_services`, tell the user which service to
   connect in the Helm dashboard (Agents → the agent → Services) and stop. Do
   not improvise a workaround.
5. If `skills_get` says the skill is unknown or not assigned, the stub set is
   stale. Tell the user, and offer to run `helm-sync`.
"""


def load_roster(path):
    data = json.loads(Path(path).read_text())
    if isinstance(data, dict):
        data = data.get("skills", [])
    out = {}
    for s in data:
        slug = str(s.get("slug", "")).strip()
        if not SLUG_RE.match(slug):
            print(f"skip invalid slug: {slug!r}", file=sys.stderr)
            continue
        out.setdefault(slug, s)  # first server wins on duplicates
    return out


def is_stub(skill_dir):
    """True only if the YAML frontmatter (not the body) marks it as a stub."""
    if skill_dir.name in CORE | set(HYBRID.values()):
        return False
    f = skill_dir / "SKILL.md"
    if not f.exists():
        return False
    m = re.match(r"---\n(.*?)\n---", f.read_text(), re.S)
    return bool(m) and re.search(r'^\s+helm-stub: "true"\s*$', m.group(1), re.M) is not None


def main():
    args = [a for a in sys.argv[1:] if not a.startswith("--")]
    dry = "--dry-run" in sys.argv
    if len(args) != 2:
        print(__doc__)
        sys.exit(2)
    roster = load_roster(args[0])
    skills_dir = Path(args[1]) / "skills"
    skills_dir.mkdir(parents=True, exist_ok=True)

    existing = {d.name for d in skills_dir.iterdir() if d.is_dir() and is_stub(d)}
    wanted = {}
    for slug, s in roster.items():
        if slug in HYBRID:
            continue
        dir_name = f"remote-{slug}" if slug in CORE else slug
        wanted[dir_name] = s

    added, updated, removed, bumped = [], [], [], []
    for dir_name, s in sorted(wanted.items()):
        desc = " ".join(str(s.get("description", "")).split())
        desc += " (Live Helm skill: instructions are fetched from Helm when it runs.)"
        server = s.get("server")
        body = TEMPLATE.format(
            dir_name=dir_name,
            description=json.dumps(desc, ensure_ascii=False),
            slug=s["slug"],
            version=json.dumps(str(s.get("version", "unknown"))),
            requires=json.dumps(",".join(s.get("requires") or []) or "none"),
            synced=date.today().isoformat(),
            title=s.get("name") or s["slug"],
            server_hint=f" (last seen on: {server})" if server else "",
        )
        target = skills_dir / dir_name / "SKILL.md"
        if target.exists() and not is_stub(target.parent):
            print(f"refuse to overwrite non-stub skill: {dir_name}", file=sys.stderr)
            continue
        old = target.read_text() if target.exists() else None
        # Body-only version bumps need no reinstall: stubs fetch live content.
        strip = lambda t: re.sub(r"(synced|helm-version): .*", "", t or "")
        if old is None:
            added.append(dir_name)
        elif strip(old) != strip(body):
            updated.append(dir_name)
        else:
            if old != body and re.sub(r"synced: .*", "", old) != re.sub(r"synced: .*", "", body):
                bumped.append(dir_name)
            continue
        if not dry:
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_text(body)

    for dir_name in sorted(existing - set(wanted)):
        removed.append(dir_name)
        if not dry:
            shutil.rmtree(skills_dir / dir_name)

    print(json.dumps({"added": added, "updated": updated, "removed": removed,
                      "version_bumps_only": bumped, "total_stubs": len(wanted),
                      "dry_run": dry}, indent=2))


if __name__ == "__main__":
    main()
