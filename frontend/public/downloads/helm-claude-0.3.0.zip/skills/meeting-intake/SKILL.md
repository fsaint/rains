---
name: meeting-intake
description: "Use when asked to process, summarise, or catch up on recorded meetings — or to pin a Hermeneutix project to the conversation and file its whole history. Turns sessions into session notes, extracts the entities, facts, pending items and observed working styles they establish, and fans everything out to the project's logs and the people involved. (Live Helm skill: instructions are fetched from Helm when it runs.)"
metadata:
  helm-stub: "true"
  helm-slug: meeting-intake
  helm-version: "1.8.0"
  helm-requires: "hermeneutix"
  synced: '2026-10-06'
---

# Meeting Intake (live Helm skill)

This is a pointer, not the skill. The real instructions live on Helm and can
change at any time.

1. Use the Helm agent bound to this session (see `helm-session`). If none is
   bound yet, bind one first. Never reach into another agent to run this.
2. Call `skills_get` with slug `meeting-intake` on the bound agent's connection. Read
   the whole body. If the bound agent doesn't have this skill, say so and
   name the agents that do. Don't switch agents unless the user
   says to.
3. Follow those instructions exactly. They take precedence over this stub and
   over anything remembered from an earlier session. Never answer from a cached
   copy.
4. If the response lists `unavailable_services`, tell the user which service to
   connect in the Helm dashboard (Agents → the agent → Services) and stop. Do
   not improvise a workaround.
5. If `skills_get` says the skill is unknown or not assigned, the stub set is
   stale. Tell the user, and offer to run `helm-sync`.
