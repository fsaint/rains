---
name: helm-skill-authoring
description: "This skill should be used when the user asks to \"create a new Helm skill\", \"turn this into a Helm skill\", \"upload this skill to Helm\", \"edit a Helm skill\", \"change the email-triage skill\", \"fix the instructions in a skill\", \"assign a skill to this agent\", or \"bump a skill version\", or otherwise maintain the content of skills stored on Helm, as opposed to running them.\n"
metadata:
  version: "0.3.0"
---

# Author and upload Helm skills

Skills belong to a scope: they are assigned to the agent that runs them. Write
and assign skills **through the scope bound to this session** (see
`helm-session`), for that scope only.

## Ground truth

- `skills_get` returns **rendered** text, with tool and skill placeholders
  already replaced by real names. Never use it as a source to edit, commit or
  upload; doing so has corrupted skills before. Read source form only through
  `skill_authoring_get`, or from the helm-skills repo.
- Source bodies name tools as `{{tool:<name>}}` and other skills as
  `{{skill:<slug>}}`. Helm renders them per runtime. Preserve every existing
  token verbatim, and use them for new references.
- The **helm-skills repo** (`~/git/helm-skills`), when present, is also a
  source. Skills edited on the platform and in the repo are not reconciled
  automatically: every platform edit must be reported so the repo can follow.

## Pick the surface

1. **The bound scope has `skill_authoring_*` tools** (see the boot's tool
   inventory): author there. This is the normal path.
2. **It doesn't:** say Skill Authoring is not enabled on this scope, and that
   the user can enable it in the dashboard (Agents → the agent → Services →
   Skill Authoring). If the helm-skills repo is connected, offer to make the
   change there instead (edit, show the diff, commit when asked, deploy the
   way the repo's README says).
3. In an **unlocked** session, the user may instead ask to switch to a scope
   that has authoring (such as Architect). Switch only on their yes. In a
   **locked** project, never switch: authoring happens in this scope or in
   the repo.

## Create a skill

1. Read the available `skill_authoring_*` schemas; use only their parameters.
2. `skill_authoring_list` to make sure the slug is free and no existing skill
   already does this.
3. Draft:
   - `name`, and `slug` (lowercase, hyphens; stable forever).
   - `description`: one line, "Use when …", naming the triggers.
   - `body`: a procedure the agent follows literally, with tool and skill
     placeholders. Not a description of a procedure.
   - `requires` if it needs services, and `version` `1.0.0`.
4. Show the full draft. Get an explicit yes.
5. `skill_authoring_create`. It needs the user's approval: poll `get_result`
   on `APPROVAL_PENDING`.
6. Assign it to **the bound scope**: `skill_authoring_assign` with `agent_id`
   = the bound `whoami` agent id. Never assign to another scope.
7. Confirm with `skills_list` that it now appears, then `skills_get` to check
   it renders. It is usable in this session at once.

## Edit a skill

1. `skill_authoring_get` for the source and current version.
2. Draft the change. Keep the slug stable and every placeholder intact.
3. Show a before/after diff of the body and description, and the new version:
   patch for wording, minor for behaviour, major for a changed contract. Get
   a yes.
4. `skill_authoring_update` overwrites the whole skill: send the complete
   name, description and body, not just the changed part.
5. Read it back with `skill_authoring_get` to confirm.

## After a create or edit

- Report the slug and version, and say the helm-skills repo (if used) is now
  behind for that slug.
- The live roster already has it. If the slug, description, or set of skills
  changed, the plugin's trigger stubs are stale: offer `helm-sync`.

## Rules

- Never delete or unassign a skill the user didn't name.
- Platform-wide skills (`scope: "system"`) only on the user's explicit request;
  they need an admin owner.
- No credentials, tokens, agent ids or MCP URLs in a skill body.
