---
name: helm-memory
description: "Use whenever you need to look something up in memory, record a new fact, or correct something already stored — people, companies, projects, notes, and the relationships between them. Every other skill that touches memory goes through this one. (Live Helm skill: instructions are fetched from Helm when it runs.)"
metadata:
  helm-stub: "true"
  helm-slug: helm-memory
  helm-version: "1.5.3"
  helm-requires: "memory"
  synced: '2026-10-06'
---

# Helm Memory (live Helm skill)

This is a pointer, not the skill. The real instructions live on Helm and can
change at any time.

1. Use the Helm agent bound to this session (see `helm-session`). If none is
   bound yet, bind one first. Never reach into another agent to run this.
2. Call `skills_get` with slug `helm-memory` on the bound agent's connection. Read
   the whole body. If the bound agent doesn't have this skill, say so and
   name the agents that do. Don't switch agents unless the user
   says to.
3. Follow those instructions exactly. They take precedence over this stub and
   over anything remembered from an earlier session. Never answer from a cached
   copy.
4. If the response lists `unavailable_services`, tell the user which service to
   connect in the Helm dashboard (Agents → the agent → Services) and stop. Do
   not improvise a workaround.
5. If `skills_get` says the skill is unknown or not assigned, the stub set is
   stale. Tell the user, and offer to run `helm-sync`.
