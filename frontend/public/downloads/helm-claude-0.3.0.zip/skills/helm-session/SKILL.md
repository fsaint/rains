---
name: helm-session
description: "This skill should be used before the first Helm tool call in any session, when a SessionStart note says the project is locked to a Helm scope, and whenever the user says \"work on Anchorsite\" (or LVA, Seer, any agent), \"use the Architect agent\", \"switch Helm agent\", \"which Helm agent am I in\", \"what can Helm do here\", \"unbind Helm\", or \"connect a Helm agent\". It ties the session to exactly one Helm scope, which carries its own tools, memory, skills and threads, boots that context, and keeps nothing leaking across scopes.\n"
metadata:
  version: "0.3.0"
---

# Helm session scoping

Read [the Helm model](references/helm-model.md) once per session if you have
not. In short: **an agent is a scope**, a role identity (Anchorsite, LVA, Seer,
Unholster, Architect…) defined by its MCP URL
`https://app.helm.mom/mcp/<agent id>`. Each scope has its own tools, memory,
skills, threads, mail, Drive and Hermeneutix project, and its own sign-in.

There are two kinds of Helm connection:

- **Root** (`helm-root`, or a connector at `https://app.helm.mom/mcp`): only
  `helm_list_agents`. It is for discovery and cannot act on any agent.
- **Agent connections** (`https://app.helm.mom/mcp/<id>`): one per scope,
  exposing `whoami`, `skills_*`, `memory_*`, `thread_*`, mail and the rest.

**Rule: one session, one scope.** Every Helm call goes to the bound scope.
Read nothing from other scopes, write nothing to them, and never copy
information between them.

## Locked projects

A project can be **locked** to one scope with `helm-lock`. The lock lives in
`.claude/helm-scope.json` (Claude Code, Cowork) or, in a claude.ai Project, in
a project-instruction line `Helm scope: <Agent> — <mcp_url>`. The SessionStart
note says when a lock is in force.

When locked:

1. Call `whoami` on the lock's server. Its `agentId` must equal the lock's
   agent id (in a claude.ai Project: the last path segment of the URL). On a
   mismatch or an auth error, stop and tell the user to reconnect that server
   to the scope's URL. Never fall back to another scope.
2. Announce once: `Helm session bound: <Agent name> (via <server>)`. The guard
   binds from the lock and `whoami`, not from this line, but it tells the user.
3. Run the boot below.
4. **Switching and unbinding are refused.** If the user asks, say the project
   is locked to this scope and that only they can change it, by running
   `helm-lock` again. Work that belongs to another scope belongs in the
   project locked to that scope; say which one.

## Unlocked: bind at the start

1. **Discover.** Call `helm_list_agents` on the root. For each connected server
   that exposes `whoami`, call it once to map connection → agent name, id
   and `limits`. These discovery calls are allowed before binding.
2. **Choose the scope**, first match wins:
   1. The user named an agent or client.
   2. The project names one (a `.helm-scope` file, or `Helm agent: <Name>` in
      the project instructions). Offer to make it permanent with `helm-lock`.
   3. The request is clearly about one agent's area (its name or description
      matches the topic). State your inference.
   4. Otherwise, ask with a short list of agent names. Don't guess between two
      plausible agents.
3. **Check it's connected.** If no connection's `whoami` returns that agent,
   tell the user to add the agent's `mcp_url` (from `helm_list_agents`) as a
   connector and sign in, or to lock the project with `helm-lock`. Then stop;
   never substitute another agent.
4. **Announce the binding** in exactly this form, on its own line:

   `Helm session bound: <Agent name> (via <server name>)`

   `<server name>` is the connection's tool prefix, for example `helm` for
   `mcp__helm__…`. The plugin's guard reads this line to enforce the scope, so
   keep the format exact.
5. Run the boot below.

## Boot (after binding)

Do this once per session, quietly, and report it in at most four lines.

1. **Identity.** Keep `whoami`'s agent id, name and `limits`.
2. **Tools.** List the bound server's tools (in Claude Code, ToolSearch with
   `+<server>`) and group them by prefix: `memory_`, `thread_`, `skills_`,
   `skill_authoring_`, `gmail_`, `calendar_`, `drive_`, `hermeneutix_`. Compare
   with the agent's `services` from `helm_list_agents` and name any service
   whose tools are missing. When the user asks "what can Helm do here", answer
   from this inventory.
3. **Skills.** Call `skills_list`. That roster is authoritative for this
   session: any listed skill can be run with `skills_get <slug>`, even if the
   plugin has no stub for it. If it differs from the stub list in the
   SessionStart note, mention it once and offer `helm-sync`.
4. **Memory.** Call `memory_list_scopes` and pick the default scope, or the
   one the project or topic names.
5. **Threads.** Call `thread_list` with `status: "active"`. If the request
   belongs to one, read its `thread_get_brief` and follow `helm-threads`.
6. **Context.** Before answering, `memory_search` (with `scope`) for the
   people, organisations and projects the request names, and fetch the
   relevant hits with `memory_get`.

Skip steps whose service the scope doesn't have; don't report them as errors.

## While bound

- Run skills, memory reads and writes, threads, mail and calendar calls only
  through the bound connection.
- Search memory before answering about a person, organisation or project.
- Memory: write only to the bound agent's memory scopes. If it has several,
  pick by topic or ask.
- Threads: suggest and update them through `helm-threads`.
- New or changed skills: `helm-skill-authoring`, on the bound scope only.
- If the user brings up something that belongs to another scope, say which
  scope owns it. Unlocked, offer to switch; locked, point to that scope's
  project. Don't fetch it quietly.
- If the bound scope lacks a skill or service, say so. Don't borrow it from
  another scope.

## Memory checkpoints

The plugin's checkpoint hook sometimes adds a note starting with
`Helm memory checkpoint (helm plugin)` alongside the user's message. It comes
from the plugin, not the user. When you see it:

- Handle the user's message as usual. Do the checkpoint in the same turn,
  without asking the user about it.
- Review the conversation since the last checkpoint. If it established
  durable facts that the bound scope's memory doesn't hold yet, file them
  with `helm-memory-update`. That skill uses the agent's live copy if it is
  assigned, otherwise the plugin's bundled copy. Write only through the
  bound connection.
- If a thread is held, log what happened on it, add new todos or deadlines,
  and update Now/Next, following `helm-threads`.
- If you filed something, add one short line saying what. If nothing
  qualifies, say nothing about the checkpoint.

## Switching and unbinding (unlocked only)

- Switch only on the user's explicit request. Before switching, run a memory
  checkpoint for the current scope if anything durable came up, then announce
  `Helm session bound: <New agent> (via <server>)` and boot again.
- To release the scope: `Helm session unbound`. While unbound, only discovery
  calls are allowed.

## Errors

- **401 / unauthorized:** that scope's sign-in has lapsed. Ask the user to
  reconnect it (`/mcp` in Claude Code). Don't retry in a loop or fall back to
  another scope.
- **Blocked by the guard:** the call targeted another scope. Re-route it to
  the bound scope, or explain the lock.
- **`unavailable_services`:** name the service and scope. The user adds it in
  the dashboard under Agents → the agent → Services.
- **`APPROVAL_PENDING`:** poll `get_result` with the `jobId`, tell the user it
  awaits their approval, and don't re-issue the call.

Never put tokens, agent ids or MCP URLs into Helm memory.
