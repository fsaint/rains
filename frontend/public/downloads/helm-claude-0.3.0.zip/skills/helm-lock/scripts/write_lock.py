#!/usr/bin/env python3
"""Lock a project folder to one Helm scope.

Usage:
    python3 write_lock.py --project DIR --agent-id ID --agent-name NAME
        --mcp-url URL --mode project-mcp|connector [--server NAME]
        [--block SERVER ...] [--dry-run]

Writes, merging with what is there:
  .claude/helm-scope.json      the lock the plugin's hooks read
  .mcp.json                    (project-mcp only) one server "helm" at the scope URL
  .claude/settings.local.json  (project-mcp only) enables "helm" and denies
                               every blocked Helm server's tools
Prints a JSON summary. Never touches other servers or permissions.
"""
import argparse
import json
from pathlib import Path
import re
import sys
from urllib.parse import urlsplit

SERVER_RE = re.compile(r"^[A-Za-z0-9_.-]{1,64}$")
PROJECT_SERVER = "helm"


def read_json(path):
    if not path.exists():
        return {}
    data = json.loads(path.read_text())
    if not isinstance(data, dict):
        raise ValueError(f"{path} is not a JSON object")
    return data


def check_url(url, agent_id):
    u = urlsplit(url)
    parts = [p for p in u.path.split("/") if p]
    if (u.scheme != "https" or not u.hostname or u.username or u.password or u.query
            or u.fragment or len(parts) != 2 or parts[0] != "mcp" or parts[1] != agent_id):
        raise ValueError("The MCP URL must be https://<host>/mcp/<agent id> for the locked agent, "
                         "with no credentials, query or fragment.")


def plan(args):
    project = Path(args.project).resolve()
    if not project.is_dir():
        raise ValueError(f"{project} is not a folder")
    check_url(args.mcp_url, args.agent_id)
    server = PROJECT_SERVER if args.mode == "project-mcp" else args.server
    if not server or not SERVER_RE.match(server):
        raise ValueError("connector mode needs --server, the connection's tool prefix")
    blocked = sorted({b for b in args.block if b != server})
    for b in blocked:
        if not SERVER_RE.match(b):
            raise ValueError(f"invalid server name: {b!r}")

    writes = {}
    lock_path = project / ".claude/helm-scope.json"
    old_lock = read_json(lock_path)
    # Keep servers blocked by an earlier lock: they are still other scopes.
    blocked = sorted(set(blocked) | {b for b in old_lock.get("blocked_servers", [])
                                     if isinstance(b, str) and b != server})
    writes[lock_path] = {"agent_id": args.agent_id, "agent_name": args.agent_name,
                         "mcp_url": args.mcp_url, "server": server, "mode": args.mode,
                         "blocked_servers": blocked}

    if args.mode == "project-mcp":
        mcp_path = project / ".mcp.json"
        mcp = read_json(mcp_path)
        mcp.setdefault("mcpServers", {})[PROJECT_SERVER] = {"type": "http", "url": args.mcp_url}
        writes[mcp_path] = mcp

        settings_path = project / ".claude/settings.local.json"
        settings = read_json(settings_path)
        enabled = settings.get("enabledMcpjsonServers") or []
        if PROJECT_SERVER not in enabled:
            settings["enabledMcpjsonServers"] = enabled + [PROJECT_SERVER]
        disabled = settings.get("disabledMcpjsonServers") or []
        if PROJECT_SERVER in disabled:
            settings["disabledMcpjsonServers"] = [d for d in disabled if d != PROJECT_SERVER]
        perms = settings.setdefault("permissions", {})
        deny = perms.get("deny") or []
        own = f"mcp__{PROJECT_SERVER}"
        deny = [d for d in deny if d != own]
        perms["deny"] = deny + [f"mcp__{b}" for b in blocked if f"mcp__{b}" not in deny]
        writes[settings_path] = settings
    return project, writes, old_lock


def main():
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("--project", required=True)
    p.add_argument("--agent-id", required=True)
    p.add_argument("--agent-name", required=True)
    p.add_argument("--mcp-url", required=True)
    p.add_argument("--mode", required=True, choices=("project-mcp", "connector"))
    p.add_argument("--server")
    p.add_argument("--block", action="append", default=[])
    p.add_argument("--dry-run", action="store_true")
    args = p.parse_args()
    try:
        project, writes, old_lock = plan(args)
    except (ValueError, OSError, json.JSONDecodeError) as error:
        print(f"helm-lock: {error}", file=sys.stderr)
        return 1
    if not args.dry_run:
        for path, data in writes.items():
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(json.dumps(data, indent=2) + "\n")
    print(json.dumps({
        "dry_run": args.dry_run,
        "replaces_lock": old_lock.get("agent_name") if old_lock.get("agent_id") not in (None, args.agent_id) else None,
        "files": {str(path.relative_to(project)): data for path, data in writes.items()},
    }, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
