---
name: helm-lock
description: "This skill should be used when the user says \"lock this project to <agent>\", \"set the Helm scope for this project\", \"pin this folder to Seer\" (or any agent), \"change this project's Helm scope\", or \"which Helm scope is this project locked to\". It ties the current Claude Code folder, Cowork project or claude.ai Project to exactly one Helm scope, defined by that scope's MCP URL, so every session in it uses that scope and no other.\n"
metadata:
  version: "0.3.0"
---

# Lock a project to one Helm scope

A Helm scope (agent) is a role identity defined by its MCP URL,
`https://app.helm.mom/mcp/<agent id>`. Locking makes that scope the only Helm
scope a project uses. Only the user locks or re-locks a project; never do it
on your own initiative, and never during a session to get around the guard.

## 1. Choose the scope

1. Call `helm_list_agents` on the root (`helm-root`). If the project is already
   locked (`.claude/helm-scope.json` exists, or the SessionStart note says so),
   say which scope it is locked to and confirm the user wants to change it.
2. Take the scope the user named. If it's ambiguous, ask with the list of names.
3. Show the user: scope name, agent id, `mcp_url`, services. Get a yes.

## 2. Find the other Helm connections

For every connected server that has a `whoami` tool, call `whoami` once (it
returns only identity). Every server whose `agentId` is **not** the chosen one
is another scope: collect its server name (the tool prefix, for example
`claude_ai_Seer_Helm` for `mcp__claude_ai_Seer_Helm__…`) for `--block`.

## 3. Write the lock for this surface

Run the script in this skill's folder (`${CLAUDE_PLUGIN_ROOT}/skills/helm-lock/scripts/write_lock.py`)
with `--dry-run` first, show the user the files it will write, get a yes,
then run it without `--dry-run`.

**Claude Code (a folder on disk, `claude` CLI or IDE):**

```
python3 write_lock.py --project <project root> --agent-id <id> --agent-name "<name>" \
  --mcp-url <mcp_url> --mode project-mcp --block <server> --block <server> …
```

It adds one server named `helm` at the scope's URL to the project's
`.mcp.json`, enables it and denies every blocked server's tools in
`.claude/settings.local.json`, and writes the lock `.claude/helm-scope.json`.
Then tell the user:

- Restart Claude Code in this folder, approve the `helm` server, and sign in
  to it with `/mcp`. Every project uses the same tool names (`mcp__helm__…`),
  each pointed at its own scope.
- The deny rules make the other Helm connectors unusable in this folder only;
  they stay available elsewhere.
- `.mcp.json` now holds the scope URL. If the folder is a shared repo, ask
  whether to commit it (teammates then share the scope) or to add `.mcp.json`
  and `.claude/helm-scope.json` to `.gitignore`.

**Cowork (a project folder, connectors are account-wide):**

```
python3 write_lock.py --project <project folder> --agent-id <id> --agent-name "<name>" \
  --mcp-url <mcp_url> --mode connector --server <connector server name> --block <server> …
```

`--server` is the connector whose `whoami` returned the chosen agent. If no
connector does, ask the user to add the `mcp_url` as a custom connector and
sign in, then rerun. The plugin's guard enforces the lock; the connectors
themselves stay account-wide.

**claude.ai Project (no folder, no hooks):** give the user this line to paste
into the Project's instructions:

```
Helm scope: <Agent name> — <mcp_url>
```

Say plainly that this lock relies on Claude following `helm-session`: nothing
in claude.ai blocks the other connectors. For a hard lock, enable only this
scope's connector in chats of that Project.

## 4. Confirm

Report one line: `Project locked to Helm scope <name> (via <server>).` In
Claude Code, the lock takes effect after the restart; in Cowork, at the next
session. The current session stays as it is.

## Rules

- One scope per project. Re-locking replaces the scope and keeps earlier
  blocked servers blocked.
- Never put the lock's URL or agent id into Helm memory.
- If the script refuses the URL, the agent id doesn't match the URL: get the
  `mcp_url` again from `helm_list_agents`.
