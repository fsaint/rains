---
name: email-triage
description: "Use when asked to triage, tag, clean up, or catch up on email. Sorts mail into Areas and Projects, applies labels in bulk, archives noise, and hands back a short decision-oriented summary. (Live Helm skill: instructions are fetched from Helm when it runs.)"
metadata:
  helm-stub: "true"
  helm-slug: email-triage
  helm-version: "2.5.1"
  helm-requires: "gmail"
  synced: '2026-10-06'
---

# Email Triage (live Helm skill)

This is a pointer, not the skill. The real instructions live on Helm and can
change at any time.

1. Use the Helm agent bound to this session (see `helm-session`). If none is
   bound yet, bind one first. Never reach into another agent to run this.
2. Call `skills_get` with slug `email-triage` on the bound agent's connection. Read
   the whole body. If the bound agent doesn't have this skill, say so and
   name the agents that do. Don't switch agents unless the user
   says to.
3. Follow those instructions exactly. They take precedence over this stub and
   over anything remembered from an earlier session. Never answer from a cached
   copy.
4. If the response lists `unavailable_services`, tell the user which service to
   connect in the Helm dashboard (Agents → the agent → Services) and stop. Do
   not improvise a workaround.
5. If `skills_get` says the skill is unknown or not assigned, the stub set is
   stale. Tell the user, and offer to run `helm-sync`.
