#!/usr/bin/env python3
"""UserPromptSubmit hook: ask Claude for a Helm memory checkpoint when warranted.

It costs nothing unless enough new user-provided material has accumulated
since the last checkpoint and nothing was written to the bound agent's Helm
memory in the meantime. In that case it adds a short instruction to Claude's
context alongside the user's new prompt (additionalContext, which the user
does not see as an error, unlike a blocking Stop hook). Claude, who has the
full context, decides what (if anything) is worth storing. The full procedure
lives in the helm-session and helm-memory-update skills.

Environment knobs:
  HELM_MEMORY_AUTO=off        disable entirely
  HELM_MEMORY_MIN_CHARS=300   new user text needed before a checkpoint
  HELM_MEMORY_MIN_TURNS=4     ...or this many new user turns
"""
import json
import os
import re
import sys
import tempfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import helm_state  # noqa: E402
from pathlib import Path

WRITE_TOOLS = {"memory_create", "memory_update", "memory_add_attribute",
               "memory_remove_attribute", "memory_relate", "memory_set_parent",
               "memory_create_scope"}

MARKER = "Helm memory checkpoint (helm plugin)"

CONTEXT = (
    MARKER + ": bound agent {agent} via {server}. Before finishing this turn, check "
    "whether the conversation before this message established durable facts that "
    "{agent}'s Helm memory should hold and does not yet. If so, file them through "
    "{server} only, using the agent's helm-memory-update skill if it is assigned, "
    "otherwise the plugin's bundled helm-memory-update skill (see helm-session, "
    "\"Memory checkpoints\"). If a Helm thread is held, also log what happened on "
    "it (events, items, Now/Next) per helm-threads. Handle the user's message as "
    "usual; if you filed something, add one short line saying what. If nothing qualifies, say nothing "
    "about this checkpoint."
)


def user_text(entry):
    if entry.get("type") != "user":
        return ""
    content = (entry.get("message") or {}).get("content")
    if isinstance(content, str):
        return content
    parts = []
    for block in content or []:
        if isinstance(block, dict) and block.get("type") == "text":
            parts.append(block.get("text", ""))
    return "\n".join(parts)


def tool_names(entry):
    if entry.get("type") != "assistant":
        return []
    content = (entry.get("message") or {}).get("content") or []
    return [b.get("name", "") for b in content
            if isinstance(b, dict) and b.get("type") == "tool_use"]


def is_helm_write(name, server):
    """Only memory writes through the bound Helm agent's connection count."""
    s, tool = helm_state.server_of(name)
    return s == server and tool in WRITE_TOOLS


def state_path(session_id):
    sid = re.sub(r"[^A-Za-z0-9_-]", "", str(session_id or "default"))[:64]
    return Path(tempfile.gettempdir()) / f"helm-memory-{sid}.json"


def check(data, env=os.environ):
    """Return the additionalContext string, or None for no checkpoint."""
    if env.get("HELM_MEMORY_AUTO", "").lower() in ("off", "0", "false"):
        return None
    tpath = data.get("transcript_path")
    if not tpath or not Path(tpath).exists():
        return None
    lines = Path(tpath).read_text(errors="ignore").splitlines()

    state_file = state_path(data.get("session_id"))
    try:
        last = json.loads(state_file.read_text()).get("line", 0)
    except Exception:
        last = 0
    if last > len(lines):
        last = 0  # transcript was compacted or rotated

    def save():
        try:
            state_file.write_text(json.dumps({"line": len(lines)}))
        except Exception:
            pass

    found = helm_state.read_lock(data.get("cwd"))
    if found["error"]:
        return None  # an unusable lock refuses Helm calls; don't ask for writes
    bound = helm_state.load(tpath, found["lock"])["bound"]
    if bound is None:
        return None  # unscoped session: never write memory

    chars, turns, wrote = 0, 0, False
    for raw in lines[last:]:
        try:
            entry = json.loads(raw)
        except Exception:
            continue
        txt = user_text(entry).strip()
        if txt and not txt.startswith("<") and MARKER not in txt:  # skip injected/hook text
            chars += len(txt)
            turns += 1
        if any(is_helm_write(n, bound["server"]) for n in tool_names(entry)):
            wrote = True

    if wrote:
        save()  # memory was already handled this stretch
        return None
    min_chars = int(env.get("HELM_MEMORY_MIN_CHARS", "300"))
    min_turns = int(env.get("HELM_MEMORY_MIN_TURNS", "4"))
    if chars < min_chars and turns < min_turns:
        return None
    save()
    return CONTEXT.format(agent=bound["agent"], server=bound["server"])


def main():
    ctx = check(json.load(sys.stdin))
    if ctx:
        print(json.dumps({"hookSpecificOutput": {
            "hookEventName": "UserPromptSubmit",
            "additionalContext": ctx}}))


if __name__ == "__main__":
    main()
