#!/usr/bin/env python3
"""SessionStart hook: tell Claude which Helm scope this project is locked to
(or that it must bind one), and which Helm skill stubs the plugin carries so
Claude can spot roster drift against the live skills_list."""
import json
import os
from pathlib import Path
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import helm_state  # noqa: E402


def stub_slugs(plugin_root):
    slugs = []
    for f in sorted(Path(plugin_root).glob("skills/*/SKILL.md")) if plugin_root else []:
        m = re.match(r"---\n(.*?)\n---", f.read_text(errors="ignore"), re.S)
        if m and re.search(r'^\s+helm-stub: "true"\s*$', m.group(1), re.M):
            slug = re.search(r"^\s+helm-slug:\s*(\S+)\s*$", m.group(1), re.M)
            slugs.append(slug.group(1) if slug else f.parent.name)
    return slugs


def message(data, plugin_root):
    found = helm_state.read_lock(data.get("cwd"))
    lock = found["lock"]
    if found["error"]:
        text = (f"Helm plugin: this project's Helm lock is unusable ({found['error']}). "
                "Helm agent calls are refused until it is fixed; offer to run helm-lock.")
    elif lock:
        text = (f"Helm plugin: this project is locked to Helm scope {lock['agent_name']} "
                f"(agent id {lock['agent_id']}, via server {lock['server']}). Run the "
                "helm-session boot on that server now: whoami must return that agent id. "
                "Use no other Helm agent here. Switching and unbinding are disabled in this "
                "project; only the user can change the lock, with helm-lock.")
    else:
        text = ("Helm plugin: this session uses at most one Helm agent at a time. Before "
                "any Helm tool call (other than discovery), follow the helm-session skill: "
                "choose the agent, then announce 'Helm session bound: <Agent> (via <server>)'.")
        if found["hint"]:
            text += f" This project's .helm-scope names the agent: {found['hint']}."
    slugs = stub_slugs(plugin_root)
    if slugs:
        text += (" Installed Helm skill stubs: " + ", ".join(slugs) + ". Compare with the "
                 "bound agent's skills_list during boot; offer helm-sync if they differ.")
    return text


def main():
    try:
        data = json.load(sys.stdin)
    except Exception:
        data = {}
    print(message(data if isinstance(data, dict) else {}, os.environ.get("CLAUDE_PLUGIN_ROOT")))


if __name__ == "__main__":
    main()
