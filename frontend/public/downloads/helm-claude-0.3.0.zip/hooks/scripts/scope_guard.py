#!/usr/bin/env python3
"""PreToolUse hook: keep Helm calls inside the agent bound to this session.

Unlocked projects: only servers proven to be Helm agents (their whoami returned
an agentId) are policed, against the agent the session announced.
Locked projects (.claude/helm-scope.json): the lock's agent is the only one
allowed; servers it lists as blocked, and any server whose whoami proved a
different agent, are refused. Every other tool passes. HELM_GUARD=off disables it.
"""
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import helm_state  # noqa: E402

IDENTITY = {"whoami", "helm_list_agents"}


def deny(reason):
    print(json.dumps({"hookSpecificOutput": {
        "hookEventName": "PreToolUse",
        "permissionDecision": "deny",
        "permissionDecisionReason": reason}}))


def wait_seconds():
    try:
        return float(os.environ.get("HELM_GUARD_WAIT", "1.5"))
    except ValueError:
        return 1.5


def guard_locked(lock, server, tool, tpath):
    name = lock["agent_name"]
    if server in lock["blocked_servers"] and tool not in IDENTITY:
        deny(f"Helm scope guard: this project is locked to '{name}' (via {lock['server']}); "
             f"{server} is another Helm scope. Open the project locked to that scope instead.")
        return
    if server == lock["server"]:
        if tool in helm_state.DISCOVERY:
            return
        st = helm_state.load(tpath, lock)
        if st["bound"] is None and server not in st["helm_ids"]:
            # whoami may have just returned and not be on disk yet.
            st = helm_state.load_settled(tpath, lambda s: s["bound"] is not None,
                                         wait_seconds(), lock=lock)
        proved = st["helm_ids"].get(server)
        if st["bound"] is not None:
            return
        if proved is None:
            deny(f"Helm scope guard: this project is locked to '{name}'. Call whoami on "
                 f"{server} first to verify the connection is that agent.")
        else:
            deny(f"Helm scope guard: {server} answers as agent "
                 f"'{st['helm_servers'].get(server, '?')}', not the locked '{name}'. "
                 f"Reconnect {server} to the locked scope's MCP URL; do not use it meanwhile.")
        return
    if tool in IDENTITY:
        return
    st = helm_state.load(tpath, lock)
    if server in st["helm_ids"]:
        deny(f"Helm scope guard: this project is locked to '{name}' (via {lock['server']}), "
             f"but {server} is Helm agent '{st['helm_servers'].get(server, '?')}'. "
             f"Use {lock['server']}, or open the project locked to that scope.")


def guard_unlocked(server, tool, tpath):
    if tool in helm_state.DISCOVERY:
        return
    st = helm_state.load(tpath)
    if server not in st["helm_servers"]:
        return  # not a known Helm agent connection
    if st["bound"] is None or st["bound"]["server"] != server:
        # A bind announced earlier in this same message may not be flushed to
        # the transcript yet; give it a moment before refusing.
        st = helm_state.load_settled(
            tpath, lambda s: s["bound"] is not None and s["bound"]["server"] == server,
            wait_seconds())
    agent = st["helm_servers"].get(server, "?")
    bound = st["bound"]
    if bound is None:
        deny(f"Helm scope guard: no Helm agent is bound to this session, and "
             f"{tool} would act as agent '{agent}'. Follow helm-session: choose "
             f"the agent and announce 'Helm session bound: <Agent> (via <server>)' first.")
    elif server != bound["server"]:
        deny(f"Helm scope guard: this session is bound to '{bound['agent']}' "
             f"(via {bound['server']}), but {tool} targets '{agent}' (via {server}). "
             f"Use the bound agent, or ask the user whether to switch.")


def main():
    if os.environ.get("HELM_GUARD", "").lower() in ("off", "0", "false"):
        return
    data = json.load(sys.stdin)
    server, tool = helm_state.server_of(data.get("tool_name", ""))
    if not server:
        return
    tpath = data.get("transcript_path")
    found = helm_state.read_lock(data.get("cwd"))
    if found["error"]:
        st = helm_state.load(tpath)
        if server in st["helm_ids"] and tool not in IDENTITY:
            deny(f"Helm scope guard: the project's Helm lock is unusable ({found['error']}). "
                 f"Fix it with helm-lock before using Helm here.")
        return
    if found["lock"]:
        guard_locked(found["lock"], server, tool, tpath)
    else:
        guard_unlocked(server, tool, tpath)


if __name__ == "__main__":
    main()
