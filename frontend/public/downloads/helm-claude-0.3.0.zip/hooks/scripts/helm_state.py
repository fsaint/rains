"""Shared transcript and lock-file parsing for the helm plugin hooks."""
import json
import re
import time
from pathlib import Path

BIND_RE = re.compile(r"^\s*`?Helm session bound:\s*(.+?)\s*\(via\s+([A-Za-z0-9_.-]+)\)`?\s*$", re.M)
UNBIND_RE = re.compile(r"^\s*`?Helm session unbound`?\s*$", re.M)
DISCOVERY = {"whoami", "skills_list", "skills_list_library", "memory_list_scopes",
             "helm_list_agents"}
LOCK_FILE = Path(".claude") / "helm-scope.json"
LEGACY_LOCK = ".helm-scope"
LOCK_DEPTH = 4  # cwd and up to three parents


def server_of(tool_name):
    """mcp__<server>__<tool> -> (server, tool); otherwise (None, None)."""
    if not tool_name.startswith("mcp__"):
        return None, None
    rest = tool_name[5:]
    if "__" not in rest:
        return None, None
    server, tool = rest.split("__", 1)
    return server, tool


def read_lock(cwd=None):
    """Find the project's Helm scope lock.

    Returns {"lock": dict|None, "hint": str|None, "error": str|None, "path": str|None}.
    A lock pins the project to one agent for good; a legacy .helm-scope file only
    names a preferred agent and locks nothing. A lock file that exists but cannot
    be used is reported as an error so callers can fail closed.
    """
    base = Path(cwd) if cwd else Path.cwd()
    for d in [base, *base.parents][:LOCK_DEPTH]:
        f = d / LOCK_FILE
        if f.is_file():
            try:
                data = json.loads(f.read_text())
            except Exception:
                return {"lock": None, "hint": None, "path": str(f),
                        "error": f"{f} is not valid JSON"}
            missing = [k for k in ("agent_id", "agent_name", "server")
                       if not isinstance(data.get(k), str) or not data[k].strip()]
            if missing:
                return {"lock": None, "hint": None, "path": str(f),
                        "error": f"{f} lacks {', '.join(missing)}"}
            blocked = data.get("blocked_servers") or []
            data["blocked_servers"] = [s for s in blocked if isinstance(s, str)]
            return {"lock": data, "hint": None, "error": None, "path": str(f)}
        legacy = d / LEGACY_LOCK
        if legacy.is_file():
            lines = legacy.read_text(errors="ignore").strip().splitlines()
            hint = lines[0].strip()[:80] if lines else None
            return {"lock": None, "hint": hint or None, "error": None, "path": str(legacy)}
    return {"lock": None, "hint": None, "error": None, "path": None}


def _blocks(entry):
    content = (entry.get("message") or {}).get("content")
    if isinstance(content, str):
        return [{"type": "text", "text": content}]
    return [b for b in content or [] if isinstance(b, dict)]


def _result_text(block):
    c = block.get("content")
    if isinstance(c, str):
        return c
    return " ".join(x.get("text", "") for x in c or [] if isinstance(x, dict))


def _identity(txt):
    """whoami returns {"agentId", "name", "limits"}; tolerate wrapped text."""
    try:
        data = json.loads(txt)
        if isinstance(data, dict) and data.get("agentId"):
            return str(data["agentId"]), str(data.get("name") or "?")
    except Exception:
        pass
    aid = re.search(r'"agentId"\s*:\s*"([^"]+)"', txt)
    if not aid:
        return None
    name = re.search(r'"name"\s*:\s*"([^"]+)"', txt)
    return aid.group(1), name.group(1) if name else "?"


def load(transcript_path, lock=None):
    """Return dict: helm_servers {server: agent}, helm_ids {server: agentId},
    bound {agent, server} or None.

    With a lock, bind lines are ignored: the session is bound exactly when the
    lock's server has proved, through whoami, to be the locked agent.
    """
    helm_servers, helm_ids, pending, bound = {}, {}, {}, None
    p = Path(transcript_path or "")
    lines = p.read_text(errors="ignore").splitlines() if p.is_file() else []
    for raw in lines:
        try:
            entry = json.loads(raw)
        except Exception:
            continue
        for b in _blocks(entry):
            if entry.get("type") == "assistant" and b.get("type") == "tool_use":
                server, tool = server_of(b.get("name", ""))
                if tool == "whoami":
                    pending[b.get("id")] = server
            elif b.get("type") == "tool_result" and b.get("tool_use_id") in pending:
                ident = _identity(_result_text(b))
                if ident:
                    server = pending[b["tool_use_id"]]
                    helm_ids[server], helm_servers[server] = ident
            elif lock is None and entry.get("type") == "assistant" and b.get("type") == "text":
                t = b.get("text", "")
                # A bind only counts if that server's whoami already proved it
                # is that agent; example text in prose can't create a binding.
                for m in BIND_RE.finditer(t):
                    agent, server = m.group(1).strip(), m.group(2)
                    if helm_servers.get(server, "").lower() == agent.lower():
                        bound = {"agent": helm_servers[server], "server": server}
                if UNBIND_RE.search(t):
                    bound = None
    if lock is not None and helm_ids.get(lock["server"]) == lock["agent_id"]:
        bound = {"agent": helm_servers.get(lock["server"]) or lock["agent_name"],
                 "server": lock["server"]}
    return {"helm_servers": helm_servers, "helm_ids": helm_ids, "bound": bound}


def load_settled(transcript_path, ok, timeout=1.5, interval=0.15, lock=None):
    """Re-read the transcript until ok(state) holds or timeout passes.

    Claude Code writes the transcript asynchronously, so when PreToolUse fires
    it may not yet hold the current message's text, e.g. a bind announcement
    made just before the tool call. Waiting briefly lets that text land.
    """
    deadline = time.monotonic() + max(timeout, 0)
    st = load(transcript_path, lock)
    while not ok(st) and time.monotonic() < deadline:
        time.sleep(interval)
        st = load(transcript_path, lock)
    return st
