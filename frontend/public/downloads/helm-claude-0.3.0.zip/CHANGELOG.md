# Changelog

## 0.3.0

- **Project scope lock.** New `helm-lock` skill ties a project to one Helm
  scope, defined by its MCP URL. In Claude Code it adds a `helm` server to the
  project's `.mcp.json`, denies the other Helm connectors in
  `.claude/settings.local.json`, and writes `.claude/helm-scope.json`. Cowork
  writes the lock file only; claude.ai Projects get a `Helm scope:` line.
- **Lock-aware hooks.** The scope guard binds from the lock once the lock
  server's `whoami` returns the locked agent id, refuses blocked servers and
  any other proven Helm agent, ignores bind/unbind lines, and fails closed on
  an unusable lock file. SessionStart names the lock and lists the installed
  skill stubs. The memory checkpoint uses the lock binding and asks for thread
  updates too.
- **Threads.** New `helm-threads` skill (live `threads` skill, bundled
  fallback): suggest with `thread_propose` after a duplicate check, work a
  held thread, back it with memory through `thread_attach_source`.
- **Session boot.** `helm-session` now inventories the scope's tools, loads the
  live `skills_list`, picks the memory scope, checks active threads and
  searches memory for the request's context.
- **Skill authoring per scope.** `helm-skill-authoring` creates and assigns
  skills through the bound scope's `skill_authoring_*` tools, for that scope
  only; no switch to Architect in a locked project.
- `helm-sync` treats `helm-lock` as core and `helm-threads` as covering the
  `threads` slug, and reports drift only for the locked scope.
- Shared Helm model reference (`skills/helm-session/references/helm-model.md`).

## 0.2.4

- **Memory checkpoint no longer shows as "Stop hook error".** The checkpoint
  moved from a blocking Stop hook to a `UserPromptSubmit` hook that adds a
  short note to Claude's context (`additionalContext`) with the next message.
  Claude runs the checkpoint in that turn alongside the user's request.
  Thresholds, state file and `HELM_MEMORY_*` variables are unchanged. The
  procedure now lives in `helm-session` ("Memory checkpoints"), not in the
  hook text.
- **Bundled `helm-memory-update` fallback.** The skill calls `skills_get` once
  on the bound agent. If the skill is unknown or not assigned there, it
  follows bundled instructions: fetch by id, `section`/`append` updates with
  `if_version`, never a full `content` resend, replace the whole section to
  insert at its top, no credentials, tokens or MCP URLs. `helm-sync` no longer
  generates or overwrites this skill.
- **Only writes through the bound Helm server count.** A memory write on
  another server (REINS or any other memory MCP) no longer suppresses the
  checkpoint. A write via `mcp__<bound server>__memory_*` does.
- **Same-turn bind is accepted by the scope guard.** Claude Code writes the
  transcript asynchronously, so a bind announced just before a tool call may
  not be on disk yet. The guard now re-reads the transcript for up to
  `HELM_GUARD_WAIT` seconds (default 1.5) before denying.
- Tests for `memory_checkpoint.py` and `scope_guard.py` with fixture
  transcripts (`tests/test_claude_hooks.py` in the source repo).
