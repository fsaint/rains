# The Helm model

Both Helm plugins (Claude and ChatGPT) work from this model. Copies are bundled
as `references/helm-model.md` in each plugin's session skill; keep them
identical to this file.

## Scope (agent)

Helm calls a scope an **agent**. A scope is a role identity: the user acts
through it on the outside world (mail, Drive, calendar, Hermeneutix recordings)
and it owns its own tools, memory, skills and threads.

- A scope is defined by its **MCP URL**, `https://app.helm.mom/mcp/<agent id>`.
  Connecting to that URL, and signing in to it, is what gives access to the
  scope. `whoami` on it returns `{"agentId", "name", "limits"}`.
- The **root** `https://app.helm.mom/mcp` only discovers scopes:
  `helm_list_agents` returns each one's `id`, `name`, `description`,
  `mcp_url` and `services`. It cannot act on any scope.
- **A project is locked to one scope.** Inside a harness project (Claude Code
  folder, Cowork project, claude.ai Project, ChatGPT project) every Helm call
  goes to the locked scope. The lock is set by the user and never changes
  during a session. Information is never read from, written to, or copied
  between scopes.

## Tools

A scope exposes the tools of the services enabled on it. Group them by prefix:

| Prefix | Service |
|---|---|
| `whoami`, `get_result` | Built in: identity and limits; status of an approval job |
| `memory_` | Memory (on by default) |
| `skills_` | Running skills (on by default) |
| `thread_` | Threads (on by default) |
| `skill_authoring_` | Writing and assigning skills (enabled per scope) |
| `gmail_`, `calendar_`, `drive_` | Google services on the scope's linked accounts |
| `hermeneutix_` | Meeting recordings, limited to the scope's project |

`helm_list_agents` names the services each scope has. A service listed there
whose tools are missing from the connection usually needs re-authentication.
A tool result with `unavailable_services` names a service to enable in the
dashboard (Agents → the agent → Services).

Consequential tools return `APPROVAL_PENDING` with a `jobId`: the user
approves on their phone. Poll `get_result` with that id; never call the tool
again while it is pending.

## Memory

Durable knowledge, split into **memory scopes** (`memory_list_scopes`) inside
the agent. Entries never cross memory scopes.

- Read: `memory_search` (always with `scope`), then `memory_get` by id.
- Write: `memory_create`; `memory_update` with `section` or `append` and
  `if_version`; `memory_relate` for relationships.
- Never store credentials, tokens, agent ids or MCP URLs.

Search memory before answering about a person, organisation or project, so
the answer carries what the user already recorded.

## Skills

Instructions the scope follows, assigned per scope.

- `skills_list` is the live roster for this scope; `skills_get <slug>` returns
  the current body. Always run a skill from `skills_get`, never from a copy.
- `skills_get` returns **rendered** text: tool and skill placeholders already
  replaced by real names. Never edit, commit or upload that text.
- Authoring uses `skill_authoring_list`, `_get`, `_create`, `_update`,
  `_delete`, `_assign`, `_unassign`, on scopes that have the service. Bodies
  are source form: name tools and skills with Helm's double-brace `tool:` and
  `skill:` placeholders, which Helm renders per runtime. `_update` overwrites
  the whole skill. A skill does nothing until assigned. Every write needs the
  user's approval.

## Threads

A **thread** is a first-class object the user creates to hold something that
needs attention over days or weeks: a launch, a move, a hiring round. It is
not a memory entry, though it is backed by memory.

- It has a **goal**, a target date, a **Past / Now / Next** narrative, **items**
  (todo, deadline, reminder, milestone), an **event** timeline, **sources**
  and **watchers** (Gmail thread, query or sender; Hermeneutix project or
  meeting) whose finds arrive as **candidates**.
- It lives in exactly one memory scope. Details belong in memory entries in
  that scope, linked with `thread_attach_source` (`memory_entry_id`). Change a
  thread only through `thread_*` tools, never with `memory_update`.
- `thread_propose`, `thread_close` and `thread_add_watcher` need the user's
  approval. Nothing exists until they approve.
- A thread is distinct from a project: a project is a durable memory entry; a
  thread is a push with a goal and a date, usually inside a project.

| Need | Tool |
|---|---|
| Find threads | `thread_list` (`status`, `scope`) |
| Read one | `thread_get_brief` |
| Suggest one | `thread_list` first, then `thread_propose` |
| Something happened | `thread_log_event` |
| Something to do | `thread_add_item`, `thread_update_item` |
| Narrative | `thread_update_now` (`now`, `next`, `past_append`) |
| Link evidence | `thread_attach_source` |
| Watcher finds | `thread_list_candidates`, `thread_accept_candidate`, `thread_dismiss_candidate` |
| Lifecycle | `thread_pause`, `thread_resume`, `thread_close` |

## Session boot

The project's scope comes first. A project is locked to one scope, and every
session boots that scope before any other work, because the scope decides
which MCP server, skills, memory and threads apply. A project with no lock asks
the user which scope to lock it to (or whether it uses no Helm) before doing
the request.

The boot, run first in every session:

1. `whoami`: confirm the agent id and read its limits.
2. Inventory the scope's tools by prefix, and note missing services.
3. `skills_list`: the live skill roster for this session.
4. `memory_list_scopes`: choose the memory scope.
5. `thread_list` with `status: "active"`: match the request to a thread and
   read its `thread_get_brief`.
6. `memory_search` for the people, organisations and projects the request
   names.
