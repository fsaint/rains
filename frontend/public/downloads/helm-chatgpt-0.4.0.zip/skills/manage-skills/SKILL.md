---
name: manage-skills
description: Use when the user asks what Helm skills are available or wants to run one, including Helm's email triage, email sweep, email send, calendar review, meeting intake, project review, memory scopes, dream, boot or help skills, or any slug in the agent's skills_list; or wants to create, turn something into, upload, edit, fix, version or assign a skill on the Helm agent bound to this chat.
---

# Manage Helm skills

Skills are instructions assigned to a Helm agent. First apply the bundled `start-helm-session` skill to establish or reuse this chat's verified agent. Use only that child's tools, and act only for that agent. See [the Helm model](../start-helm-session/references/helm-model.md).

## Available skills and updates

1. Call `skills_list`. That roster is current: skills added on Helm appear without updating this plugin.
2. To run a skill, call `skills_get` with its slug on the bound connection, read the whole body, and follow it exactly for this request. It takes precedence over this plugin's text and over anything remembered from an earlier chat. Fetch it again in a later chat rather than relying on an earlier copy.
3. If the response lists `unavailable_services`, name the service the user must enable for the agent in the Helm dashboard (Agents → the agent → Services) and stop. Don't improvise a workaround.
4. If `skills_get` says the skill is unknown or not assigned to this agent, say so. Don't borrow it from another agent; the user can assign it in the Helm dashboard (Agents → the agent → Skills).

## Create or upload a skill

Authoring requires the agent's `skill_authoring_*` tools. If they are absent, say Skill Authoring is not enabled for this agent; the user can enable it in the Helm dashboard (Agents → the agent → Services). Do not switch to another agent to author, and never in a project locked to a scope.

1. Read the authoring tools' schemas and use only their parameters.
2. Call `skill_authoring_list` to check that the slug is free and that no existing skill already does this.
3. Draft the name, a stable lowercase slug, a one-line "Use when …" description naming the triggers, `requires` if it needs services, version `1.0.0`, and a body written as a procedure the agent follows literally, not a description of one. In the body, name tools and other skills with Helm's double-brace `tool:` and `skill:` placeholders, which Helm renders for each runtime.
4. Show the complete draft and get the user's agreement.
5. Call `skill_authoring_create`, then `skill_authoring_assign` with `agent_id` set to the verified `whoami` ID. Never assign to another agent. Each write requires the user's approval; follow the bundled `review-helm-actions` workflow for `APPROVAL_PENDING`.
6. Confirm with `skills_list` that it appears, then `skills_get` to check it renders. It is usable in this chat at once.

## Edit a skill

1. Read the source with `skill_authoring_get`. Never use `skills_get` output as a source: it is rendered and its placeholders are already replaced.
2. Keep the slug and every placeholder intact. Show a before/after diff and the proposed version (patch for wording, minor for behavior, major for a changed contract). Get agreement.
3. `skill_authoring_update` replaces the whole skill: send the complete name, description and body. Read it back with `skill_authoring_get`.

After a create or edit, report the slug and version, and say that a helm-skills repository, if the user keeps one, is now behind for that slug. Platform-wide skills (`scope: "system"`) only on the user's explicit request; they need an admin owner.

Never delete or unassign a skill the user did not name, and never put credentials, tokens, agent IDs or MCP URLs in a skill body. Report the slug, version and agent, and any pending approval.
