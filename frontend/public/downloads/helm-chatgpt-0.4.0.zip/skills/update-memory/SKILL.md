---
name: update-memory
description: Use at memory checkpoints during a Helm chat and again at its end, or when the user asks to remember, log or capture what was just discussed. Files the people, companies, projects and facts the conversation established into the bound Helm scope, updating existing entries instead of duplicating them. Prefers the agent's live helm-memory-update skill.
---

# Update Helm memory

## 1. Pick the instructions (once per chat)

1. Apply the bundled `start-helm-session` skill to use this chat's verified agent and memory scope. If no agent is bound, stop: an unscoped chat never writes Helm memory.
2. Call `skills_get` with slug `helm-memory-update` on the bound connection, once per chat.
   - If it returns the skill, follow those instructions. They take precedence over this file.
   - If it is unknown or not assigned, use the bundled instructions below. Do not call `skills_get` for it again this chat, and do not borrow it from another agent. Mention once that the skill can be assigned to this agent in the Helm dashboard (Agents → the agent → Skills).

## 2. Bundled instructions (fallback)

Write only through the bound agent's connection and only to its memory scopes. If it has several, pick by topic or ask.

**What to file.** Only durable facts this conversation actually established: people, companies, projects, decisions, commitments, preferences, dates. Skip speculation, small talk and anything already stored. Never store credentials, tokens, API keys, agent IDs or MCP URLs.

**Find before you write.**

1. `memory_search` (with `scope`) for each entity. Update an existing entry instead of creating a duplicate.
2. Fetch the match by ID with `memory_get`, not by title, and note its `version`.

**Update, don't resend.**

- Use `memory_update` with `section` or `append`, and always pass `if_version` with the version you just read.
- Never resend a whole body with `content`; a full resend can silently drop sections. Use `content` only for a brand-new entry you just created.
- `section` with `mode: "append"` adds text at the end of that section. To put a new item at the top of a section (for example the newest item in a `Status` section), read the section, then use `section` with `mode: "replace"` and the whole new section body, new item first.
- On `VERSION_CONFLICT`, re-read the entry by ID and re-apply your change. Don't fall back to `content`.

**Create and link.**

- New entity: `memory_create` with the right type (person, company, project, note) in the right scope, with a short factual body.
- Relationships: `memory_relate` (person works at company, project belongs to company).
- When you add significant new entries, add one line to the scope's index with `append` or `section`, never a full resend.
- If the fact belongs to a held thread, link the entry with `thread_attach_source` through the bundled `work-threads` workflow.

For `APPROVAL_PENDING`, follow the bundled `review-helm-actions` workflow. Merges, replacements, deletions and scope moves follow the `maintain-memory` policy instead.

**Report.** One short line naming what you filed. If nothing qualified, say nothing during an automatic checkpoint, or "No Helm memory update." when asked directly.
