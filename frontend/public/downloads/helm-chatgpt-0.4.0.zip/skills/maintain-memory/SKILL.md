---
name: maintain-memory
description: Use when the user asks to save a selected excerpt to Helm, review or repair scoped memory, run memory maintenance, or configure or inspect a Helm maintenance schedule.
---

# Maintain Helm memory

Read [memory policy](references/memory-policy.md) before choosing a write or scheduling path. These instructions use Helm's existing server capabilities; they do not create a scheduler or enforce server policy.

First apply the bundled `start-helm-session` skill to establish or reuse this chat's verified agent and memory scope. If it is unavailable, report the incomplete plugin rather than guess a connection. Use canonical names below through the selected child's host-exposed tools; the master directory cannot run maintenance. Keep connection, scope, entry IDs, and job IDs together. Follow the session skill's new-chat recommendation and explicit-switch procedure before changing agents, projects, or scopes.

## Save an excerpt

Use only the excerpt or facts the user explicitly selected for storage. Search with `memory_search(query, scope)` for existing entries; fetch matches by ID. Preserve source attribution and distinguish a direct quote from a summary. Read a scope's writing conventions if available, resolving config pages by scoped search and ID rather than an unqualified title.

For a user-requested new entry, use `memory_create` only if advertised and permitted by the connected server, passing the explicit scope and schema-required fields. This authorizes the requested addition, not automatic collection of other transcript content. When the saved fact belongs to an active Helm thread, also link the entry with `thread_attach_source` (`source_type: "memory"`, `memory_entry_id`) through the bundled `work-threads` workflow; never change the thread with memory tools.

To update an existing entry, or to file what a conversation established, follow the bundled `update-memory` workflow: fetch by ID, `section` or `append` with `if_version`, never a full `content` resend.

For replacements, merges, deletion, or moving information between scopes, prepare exact proposed changes and require the server review path described in the policy reference. Do not treat a permissive write tool as evidence that review occurred.

## Review or run maintenance

Prefer an advertised server maintenance tool that accepts the requested scope and returns a run ID and policy/version information. Validate client compatibility when the server exposes that contract. Use dry-run mode when requested. Inspect status on the same connection, and report applied changes separately from proposals and pending reviews.

If no such tool is advertised, offer or perform the requested read-only review with scoped `memory_dream`, `memory_list`, `memory_search`, and `memory_get`, as available. Report coverage and proposed repairs. Do not call this a server maintenance run or assume its policy is pinned. A result at its limit is potentially truncated; narrow the query or disclose incomplete coverage.

## Schedules

Use only an advertised Helm scheduling tool and its actual input schema. Confirm the intended connection, scopes, sources, local time, and timezone from the user's request; clarify missing values. Read back the persisted schedule and next run before claiming it is enabled. If the server exposes no scheduler, say this connection cannot configure scheduled maintenance. Do not substitute a ChatGPT recurring task, local cron job, or repeated client-side polling.

For `APPROVAL_PENDING`, follow the bundled `review-helm-actions` workflow on the same connection. Return the selected connection/scope, actual outcome, available run or job ID, and pending decisions. Never report a proposal or an accepted request as an applied memory change.
