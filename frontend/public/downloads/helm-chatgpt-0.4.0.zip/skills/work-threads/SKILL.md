---
name: work-threads
description: Use when the user asks about Helm threads, asks what is active or due, wants to pick up, continue, update, release or close a thread, log events, todos, deadlines or Now/Next on a held thread, or when a topic with a goal and a deadline that will take attention over days or weeks deserves a thread to be suggested.
---

# Work with Helm threads

A thread is a first-class Helm object the user creates for something that needs their attention: a goal, a Past / Now / Next narrative, todos, deadlines, reminders, an event timeline, sources and watchers. It lives in one memory scope and is backed by memory, but it is not a memory entry. See [the Helm model](../start-helm-session/references/helm-model.md).

First apply the bundled `start-helm-session` skill to establish or reuse this chat's verified agent and memory scope. Use only that child's `thread_*` tools. If it has none, say the Threads service is not enabled on the agent and stop.

Call `skills_get` with slug `threads` once per chat. If the agent returns it, follow it; it takes precedence over the rules below. If it is unknown or unassigned, use these rules, don't call `skills_get` for it again this chat, and mention once that the `threads` skill can be assigned to this agent in the Helm dashboard (Agents → the agent → Skills).

## Approvals

`thread_propose`, `thread_close` and `thread_add_watcher` require the user's approval on their phone and return `APPROVAL_PENDING` with a `jobId`. Follow the bundled `review-helm-actions` workflow. Never call the same tool again while it is pending, and never report a proposal as a created thread.

## Suggest a thread

Suggest a thread only for a topic with a goal or deadline that will take attention over days or weeks. A one-off question is not a thread, and something without an end is a project in memory.

1. Call `thread_list` in the selected scope so you do not duplicate one.
2. Draft `title`, `goal`, `target_date`, `past`, `now`, `next` and `scope`. Add a watcher only if the user wants one, choosing the narrowest source they can already read: one Gmail thread, then a sender, then a tight query; a Hermeneutix meeting before a whole project.
3. Show the draft. Call `thread_propose` only after the user agrees.

When you notice such a topic during other work, offer the thread in one line; don't propose without the user's yes.

## Pick up a thread

1. Find it with `thread_list` if you have no ID, then read `thread_get_brief`. Summarise Past, Now and Next in at most five lines, and surface anything due or new candidates first.
2. Print once, on its own line: **Helm thread held: <title>**

## While a thread is held

- At the start of each working turn, read `thread_get_brief` again. Surface what is due or has fired first.
- Watcher candidates (`thread_list_candidates`): show them and ask. `thread_accept_candidate` for ones that belong, `thread_dismiss_candidate` for ones that don't.
- Something happened (a call, a decision, a delivery): `thread_log_event`.
- Something to do: `thread_add_item` (`todo`, `deadline` with `due_at`, `reminder` with `remind_at`, `milestone`); change or finish it with `thread_update_item`.
- Keep the narrative current with `thread_update_now` (`now`, `next` replace; `past_append` adds).
- **Backed by memory.** Durable detail (people, decisions, documents) goes into memory in the thread's scope through the bundled `update-memory` workflow, then is linked with `thread_attach_source` (`source_type: "memory"`, `memory_entry_id`). Attach the emails and meetings that matter the same way. Never change a thread with memory tools.
- Stay on the thread. If the user turns to something unrelated, say the thread is held and ask whether to release it.
- `thread_pause` / `thread_resume` only when the user asks.

## Release and close

- Release only when the user asks: print **Helm thread released**. The thread stays active.
- Close when the goal is met or the user ends it: read the brief, draft a retrospective, propose `cancel` or `carry` (with `successor_thread_id`) for every open item, and on the user's yes call `thread_close` with `thread_id`, `retrospective` and `decisions`. Record the outcome on the parent project in memory in one or two lines.

Return what changed on the thread, and any pending approval with its job ID.
